var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

var VerifyToken = require(__root + 'auth/VerifyToken');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());
var Books = require('./Books');

//Enter multiple books at a time


// ENTERS BOOK INFORMATION
//validation to be done allowed only if he is editor
router.post('/insertBookInformationFromEditor', VerifyToken,function (req, res) {
    if(req.body.role==="Editor") {
    Books.create({
            author: req.body.author,
			isbn: req.body.isbn,
			title: req.body.title,
			genre: req.body.genre,
			imageLink: req.body.imageLink,
			link: req.body.link,
			isCoverAvailable:req.body.isCoverAvailable
        }, 
        function (err, user) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(user);
        });
	} else{
	   res.status(401).send("Forbidden");
	}
});

// RETURNS ALL THE BOOK IN THE DATABASE
router.get('/findAllBooks', VerifyToken,function (req, res) {
	  Books.find({}, function (err, books) {
        if (err) return res.status(500).send("There was a problem finding the books.");
        res.status(200).send(books);
    });
});

// GETS A SINGLE BOOK FROM THE DATABASE BASED 
router.get('/getBook/:search', function (req, res) {
	let searchQuery={ $or:[ {'author':req.params.search}, {'isbn':req.params.search}, {'title':req.params.search} ]}
    Books.find(searchQuery, function (err, user) {
        if (err) return res.status(500).send("There was a problem finding the books.");
        if (!user) return res.status(404).send("No user found.");
        res.status(200).send(user);
    });
});

// DELETES A BOOK FROM THE DATABASE
router.delete('/deleteBook/:id', function (req, res) {
    Books.findByIdAndRemove(req.params.id, function (err, books) {
        if (err) return res.status(500).send("There was a problem deleting the book.");
        res.status(200).send("book: "+ books.title +" was deleted.");
    });
});

// UPDATES A SINGLE BOOK IN THE DATABASE
// Added VerifyToken middleware to make sure only an authenticated user can put to this route
router.put('/updateBook/:id',  VerifyToken,  function (req, res) {
    Books.findByIdAndUpdate(req.params.id, req.body, {new: true}, function (err, books) {
        if (err) return res.status(500).send("There was a problem updating the book.");
        res.status(200).send(books);
    });
});


module.exports = router;