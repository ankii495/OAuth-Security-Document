var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

var VerifyToken = require('./VerifyToken');

router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());
var User = require('../user/User');

/**
 * Configure JWT
 */
var jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
var bcrypt = require('bcryptjs');
var config = require('../config'); // get config file

router.post('/login', function(req, res) {
  console.log("req"+req);
  console.log("req.body"+req.body.email);
  User.findOne({ email: req.body.email }, function (err, user) {
    if (err) return res.status(500).send('Error on the server.');
    if (!user) return res.status(404).send('No user found.');
	console.log("User"+ user);
	console.log("User Role"+ user.role);
	var user_role = user.role;
    
    // check if the password is valid
    var passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
    if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });

    // if user is found and password is valid
    // create a token
    var token = jwt.sign({ id: user._id }, config.secret, {
      expiresIn: 86400 // expires in 24 hours
    });

    // return the information including token as JSON
    res.status(200).send({ auth: true, token: token, role: user_role});
  });

});


// ENTERS BOOK INFORMATION
//validation to be done allowed only if he is editor
router.post('/insertBookInformationFromEditor',function (req, res) {
	console.log("req"+req.body.author);
	console.log("req"+req.body.role);
	console.log("req"+req.params.role);
    if(req.body.role==="Editor") {
    Books.create({
            author: req.body.author,
			isbn: req.body.isbn,
			title: req.body.title,
			genre: req.body.genre,
			imageLink: req.body.imageLink,
			link: req.body.link,
			isCoverAvailable:req.body.isCoverAvailable
        }, 
        function (err, user) {
            if (err) return res.status(500).send("There was a problem adding the information to the database.");
            res.status(200).send(user);
        });
	} else{
	   res.status(401).send("Forbidden");
	}
})

router.get('/logout', function(req, res) {
  res.status(200).send({ auth: false, token: null });
});

router.post('/register', function(req, res) {

  var hashedPassword = bcrypt.hashSync(req.body.password, 8);

  User.create({
    name : req.body.name,
    email : req.body.email,
    password : hashedPassword,
	role:req.body.role
  }, 
  function (err, user) {
    if (err) return res.status(500).send("There was a problem registering the user`.");

    // if user is registered without errors
    // create a token
    var token = jwt.sign({ id: user._id }, config.secret, {
      expiresIn: 86400 // expires in 24 hours
    });

    res.status(200).send({ auth: true, token: token });
  });

});


module.exports = router;