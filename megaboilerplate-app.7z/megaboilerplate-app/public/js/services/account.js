angular.module('MyApp')
  .factory('Account', function($http) {
    return {
	  saveLoginInfo: function(data) {
	    return $http.post('/saveLoginInfo', data)
	  },
      updateProfile: function(data) {
        return $http.put('/account', data);
      },
      changePassword: function(data) {
        return $http.put('/account', data);
      },
      deleteAccount: function() {
        return $http.delete('/account');
      },
      forgotPassword: function(data) {
        return $http.post('/forgot', data);
      },
      resetPassword: function(data) {
        return $http.post('/reset', data);
      }
    };
  });